# pylint: disable=C0115, R0903, C0116, C0114
from pydantic import BaseModel


class Record(BaseModel):
    id: int
    p_id: int
    description: str
    score: float

    class Config:
        orm_mode = True
