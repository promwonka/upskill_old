# pylint: disable=C0115, R0903, C0116, C0114
from sqlalchemy import Column, Integer, String, Float

from .database import Base


class Item(Base):
    __tablename__ = "items"

    id = Column(Integer, primary_key=True, index=True)
    p_id = Column(Integer, index=True)
    description = Column(String, index=True)
    score = Column(Float, index=True)
