"""
Copyright 2021 Wudi Datatech Private Limited. All Rights Reserved.
"""
# pylint: disable=C0115, R0903, C0116

import uuid
import psycopg2
import datetime
import pandas as pd

conn = psycopg2.connect(
    database="testdb",
    user="postgres",
    password="TestML123098",
    host="65.0.12.26")

cur = conn.cursor()


# def get_item_id(item_brand_name):
#     cur.execute(
#         "SELECT item_brand_id from dbfilter_1 WHERE item_brand_name = %s" % item_brand_name
#         )
#     rows = cur.fetchall()
#     last = [item for items in rows for item in items]
#     return last


def get_user(user_id):
    cur.execute(
        "SELECT user_id FROM dbfilter2 where user_id == '%s'" % user_id
        )
    rows = cur.fetchall()
    last = [item for items in rows for item in items]
    return last


def get_name_from_itemid(item_brand_id):
    cur.execute(
        "SELECT item_brand_name from dbfilter_1 WHERE item_brand_id = %s" % item_brand_id
        )
    rows = cur.fetchall()
    last = [item for items in rows for item in items]
    return last


def insert_data(user_id, brand_id, user_liked, user_addcart, user_clickdesc, user_share, user_time, recom_yn):
    cur.execute(
        "INSERT INTO dbfilter2 (table2_id, user_id, brand_id, user_liked, user_addcart,user_clickdesc,user_share,user_time,recom_yn, time_stamp) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        (
            uuid.uuid1().hex,
            user_id,
            brand_id,
            user_liked,
            user_addcart,
            user_clickdesc,
            user_share,
            user_time,
            recom_yn,
            datetime.datetime.now()
            )
        )
    print("Ok")
    conn.commit()


def get_category(brand_id):
    cur.execute(
        "SELECT category_name from dbfilter_1 WHERE brand_id = '%s'" % brand_id
        )
    rows = cur.fetchall()
    last = [item for items in rows for item in items]
    return last


def get_items_from_categ(category, user):
    cur.execute(
        "SELECT brand_id from dbfilter_1 WHERE category_name = '%s'" % category
        )
    rows = cur.fetchall()
    last = [item for items in rows for item in items]
    history = get_history(user)
    final = [x for x in last if x not in history]
    return final


def get_user_intera_history(user_id):
    cur.execute(
        "SELECT brand_id from dbfilter2 WHERE user_liked = '1' AND user_id = '%s' " % user_id
        )
    rows = cur.fetchall()
    last = [item for items in rows for item in items]
    category = get_category(last[0])
    items = get_items_from_categ(category[0], user_id)
    return items


def get_history(user_id):
    cur.execute(
        "SELECT brand_id from dbfilter2 WHERE recom_yn = '1' AND user_id = '%s' " % user_id
        )
    rows = cur.fetchall()
    last = [item for items in rows for item in items]
    return last


def get_top_ranked(products):
    bests = sorted(products, key=lambda x: int(x[1]) + int(x[2]) + int(x[2]) + int(x[2]), reverse=True)
    sorted_list = [best[0] for best in bests]
    return sorted_list


def get_productid(brand_id):
    cur.execute(
        "SELECT product_id FROM dbfilter_1 WHERE brand_id = '%s' " % brand_id
        )
    rows = cur.fetchall()
    return rows[0][0]


def get_brands(product_id):
    cur.execute(
        "SELECT brand_id, user_rating, sales_rating, buy_again FROM dbfilter_1 WHERE product_id = '%s' " % product_id
        )
    rows = cur.fetchall()
    return rows


def get_best_brand(brand, user_id):
    brands = get_brands(brand)
    bests = sorted(brands, key=lambda x: int(x[1]) + int(x[2]) + int(x[3]), reverse=True)
    history = get_history(user_id)
    last = [x for x in bests if x[0] not in history]
    return last[0][0]


def get_best_random(nums):
    cur.execute(
        "SELECT brand_id FROM dbfilter_1 ORDER BY RANDOM() LIMIT %s" % nums
        )
    rows = cur.fetchall()
    out = [item for t in rows for item in t]
    return out


def db_test():
    cur.execute(
        "SELECT * FROM dbfilter2"
        )
    rows = cur.fetchall()
    return rows

    
# new code

def insert_item(brand_id, brand_name, product_id, product_name, product_desc, category_name, subcategory_name, user_rating, sales_rating, buy_again,push_product_brand):
    cur.execute(
        "SELECT brand_id FROM dbfilter_1 where brand_id = '%s'" % brand_id
        )
    rows = cur.fetchall()


    if not rows:
        cur.execute(
            "INSERT INTO dbfilter_1 (table1_id, brand_id, brand_name, product_id, product_name, product_desc, category_name, subcategory_name, user_rating, sales_rating, buy_again, push_product_brand) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
            (
                uuid.uuid1().hex,
                brand_id,
                brand_name,
                product_id,
                product_name,
                product_desc,
                category_name,
                subcategory_name,
                user_rating,
                sales_rating,
                buy_again,
                push_product_brand
                )
            )
        print("Ok")
        conn.commit()

    else:
        cur.execute(
            "UPDATE dbfilter_1 SET table1_id='%s', brand_id='%s', brand_name='%s', product_id='%s', product_name='%s', product_desc='%s', category_name='%s', subcategory_name='%s', user_rating='%s', sales_rating='%s', buy_again='%s', push_product_brand='%s' WHERE brand_id='%s'" %
            (
                uuid.uuid1().hex,
                brand_id,
                brand_name,
                product_id,
                product_name,
                product_desc,
                category_name,
                subcategory_name,
                user_rating,
                sales_rating,
                buy_again,
                push_product_brand,
                brand_id
                )
            )
        print("replaced")
        conn.commit()


    

    



def insert_purchase_hist(user_id, brand_id, user_bought, user_return, user_cancel,  unit_price, unit_quantity, total_price, brand_discount, invoice_number, invoice_date, payment_mode,total_invoice_amount, total_invoice_discount, coupon_code, gift_or_not ):
   
    cur.execute(
        "INSERT INTO dbfilter_3 (table3_id, user_id, brand_id, user_bought, user_return,user_cancel,  unit_price, unit_quantity, total_price, brand_discount, invoice_number, invoice_date, payment_mode,total_invoice_amount, total_invoice_discount, coupon_code, gift_or_not) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        (
            uuid.uuid1().hex,
            user_id,
            brand_id,
            user_bought,
            user_return,
            user_cancel,
            unit_price,
            unit_quantity,
            total_price,
            brand_discount,
            invoice_number,
            invoice_date,
            payment_mode,
            total_invoice_amount,
            total_invoice_discount,
            coupon_code,
            gift_or_not
            )
        )
    print("Ok")
    conn.commit()

# till here

def csv_creation(up_csv):

    cur.execute(
        "SELECT * FROM dbfilter_1"
        )
    lst = cur.fetchall()

    dfc = pd.DataFrame(lst, columns = ['table1_id','brand_id', 'brand_name', 'product_id', 'product_name', 'product_desc', 'category_name', 'subcategory_name', 'user_rating', 'sales_rating', 'buy_again','push_product_brand']) 

    dfc.to_csv('list_2.csv', index = False)
    print('created successfully')
    conn.commit()

    # else:
    #     pass 