"""
Copyright 2021 Wudi Datatech Private Limited. All Rights Reserved.
"""
# pylint: disable=C0115, R0903, C0116 , C0301

from app import app
from fastapi import Request
from app.views.model import model, insert_item_fn, insert_purch_hist_fn, create_csv_fn
from pydantic import BaseModel
from typing import List


class Item(BaseModel):
    product_interaction_list: List[List[str]]
    user_id: str


#new code

class Itemfill(BaseModel):
    itemfill_list: List[List[str]]

class user_purchase(BaseModel):
    user_purchase_list: List[List[str]]

class csv_update(BaseModel):
    csv_code: List[str]


@app.post("/csv_update_code")
async def csv_update_code(request: Request, csv_update_c: csv_update):
    if request.method == 'POST':

        datamn = csv_update_c.dict()
        first_value = list(datamn.values())[0][0]

        if first_value == 'RECWUD':
            
            create_csv_fn(
                csv_update_c.dict()["csv_code"])
            data = 'created succesfully'
            return data

        else:
            return first_value





@app.post("/purchase_hist")
async def purchase_hist(request: Request, purchase_fill: user_purchase):



        """
    ### Insert as in the order

        {
                "user_purchase_list": 
                [
                        [ 
                          user_id,
                          product_brand_id,
                          user_bought,
                          user_return,
                          user_cancel,
                          unit_price,
                          unit_quantity,
                          total_price,
                          product_brand_discount,
                          invoice_number,
                          invoice_date,
                          payment_mode,
                          total_invoice_amount,
                          total_invoice_discount,
                          coupon_code,
                          gift_or_not,
                        ]
                ]
    

        }

### Insert example

    {
            "user_purchase_list": [
                    ["253","43", "1", "0", "0", "10", "1", "10", "0", "63654654inv", "31/02/2021", "cash", "100", "0", "nil","0"]
                    ]
                    
        }

### Glossary

| Variable                 | Value   | Description                                                                                                                                                         |
|--------------------------|---------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| user_id                  | VARCHAR | Id of the user whose purchase history are being sent to the API. (mandatory)                                                                                        |
| product_brand_id         | VARCHAR | This contains the brand's product id which the user purchased/cancelled/returned. (mandatory)                                                                       |
| user_bought              | VARCHAR | This shows whether this entry depicts purchase or not. "1" if it depicts purchase and "0" if not.    (mandatory)                                                    |
| user_return              | VARCHAR | This shows whether the user returned the product_brand_id. "1" if it depicts return and "0" if not.   (mandatory)                                                   |
| user_cancel              | VARCHAR | This shows whether the user cancelled the purchase of product_brand_id. "1" if it depicts cancellation and "0" if not.    (mandatory)                               |
| unit_price               | VARCHAR | This shows the price of the product_brand_id, in unit currency. (mandatory)                                                                                         |
| unit_quantity            | VARCHAR | This shows the quantity of the product_brand_id. (mandatory)                                                                                                        | 
| total_price              | VARCHAR | This shows the total price of the product_brand_id (price x quantity). (mandatory)                                                                                  |
| product_brand_discount   | VARCHAR | This provides the discount given for this particular product_brand_id. (mandatory)                                                                                  |                                
| invoice_number           | VARCHAR | This is the invoice number of the product_brand_id's purchase. (mandatory)                                                                                          |                 
| invoice_date             | VARCHAR | This is the invoice date of the product_brand_id's purchase, in ddmmyyyy format. (mandatory)                                                                        |
| payment_mode             | VARCHAR | This is the payment mode of the product_brand_id's purchase. (mandatory)                                                                                            |
| total_invoice_amount     | VARCHAR | This is the total invoice amount. (mandatory)                                                                                                                       |
| total_invoice_discount   | VARCHAR | This is the total invoice discount. Give "0" if nothing is there. (mandatory)                                                                                       |
| coupon_code              | VARCHAR | This is the coupon code applied. Give "nil" if nothing is there. (mandatory)                                                                                        |
| user_purchase_list       | LIST    | This contains the purchase details of the product_brand_id as a list. (mandatory)                                                                                   |  
| gift_or_not              | VARCHAR | This indicates whther the purchased product_brand_id is a gift or not. "1" if yes and "0" if not. (mandatory)                                                       |
                                                                                                                                                                                                         |
    """



        if request.method == 'POST':
            insert_purch_hist_fn(
                purchase_fill.dict()["user_purchase_list"])
            data = 'saved succesfully'
            return data





@app.post("/item_fill")
async def item_fill(request: Request, items_fill: Itemfill):


    """
    ### Insert as in the order

        {
                "itemfill_list": 
                [
                        [ 
                          product_brand_id, 
                          product_brand_name, 
                          product_id, 
                          product_name, 
                          product_desc, 
                          category_name, 
                          subcategory_name, 
                          user_rating, 
                          sales_rating, 
                          buy_again,
                          push_product_brand

                        ]
                ]
    

        }

### Insert example

    {
            "itemfill_list": [
                    ["253","brand sdf","1","product cdf","desc xyz","category xyz","sub category xyz", "0","1","0","1"]
                    ]
                    
        }

### Glossary

| Variable                 | Value   | Description                                                                                                                                                         |
|--------------------------|---------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| product_brand_id         | VARCHAR | Id of the product’s brand that the user views                                                                                                                       |
| product_brand_name       | VARCHAR | This shows the name of the item that user has viewed                                                                                                                |
| recom_brand_ids          | LIST    | This contains the product_brand_ids recommended for the user                                                                                                        |
| product_id               | VARCHAR | This is the id of the product                                                                                                                                       |
| product_name             | VARCHAR | This is the name of the product                                                                                                                                     |
| product_desc             | VARCHAR | This is the description of the product                                                                                                                              |
| category_name            | VARCHAR | This is the category name of the product                                                                                                                            |
| subcategory_name         | VARCHAR | This is the sub-category name of the product                                                                                                                        |
| user_rating              | VARCHAR | This is the given user rating. Give mandatory default value as 0                                                                                                    |
| sales_rating             | VARCHAR | This is the given sales rating. Give mandatory default value as 0                                                                                                   |               
| buy_again                | VARCHAR | This is indicates whether the brand will be bought again by a user. Give mandatory default value as 1                                                               |            
| itemfill_list            | LIST    | This contains the item list to be inserted into the database                                                                                                        |
| push_product_brand       | VARCHAR | Give "1" if you want to push this particular  product_brand_id, else give zero mandatorily. You can also update previous values by simply giving a new value        |             
                                                                                                                                                                                                             |
    """

    if request.method == 'POST':
        insert_item_fn(
            items_fill.dict()["itemfill_list"])
        data = 'success'
        return data

# till here

@app.get("/")
async def root(request: Request):
    if request.method == 'GET':
        return {"health": 200}


@app.post("/result")
async def result(request: Request, item: Item):
    """
### Request as in the order

        {
                "product_interaction_list": [
                        [
                          product_brand_id,
                          user_liked,
                          user_addedcart,
                          user_clickdesc,
                          user_share,
                          user_time,
                          recom_yn,
                        ],

                        [
                          product_brand_id,
                          ..............
                          ..............
                          recom_yn
                        ]

                                                ]
                        "user_id":  user_id

        }




### Request example

    {
            "product_interaction_list": [
                    ["253","1","1","0","1","0","0"],
                    ["25","1","1","0","1","0","0"],
                    ["12","0","1","1","0","1","1"],
                    ..............................
                    ..............................
                    ..............................
                    ["53","1","0","1","0","1","0"],
                    ["35","1","1","0","1","0","0"],
                    ["11","0","0","0","0","1","1"]

                                            ]
                "user_id": "23"
        }



### Glossary

| Variable                 | Value   | Description                                                                                                                                                         |
|--------------------------|---------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| product_brand_id         | VARCHAR | Id of the product’s brand that the user views                                                                                                                       |
| product_ids              | LIST    | A list of list, this list contains all the interaction details of the products                                                                                      |
| product_interaction_list | LIST    | This contains [ product_brand_id, user_liked, user_addedcart, user_clickdesc, user_shared,user_time,recom_yn] as list                                               |
| recom_yn                 | VARCHAR | This denotes whether the brand that was viewed by the user recommended by API or not                                                                                |
| user_id                  | VARCHAR | Id of the user whose product interactions are being sent to the API                                                                                                 |
| user_liked               | VARCHAR | Denote whether the user liked it or not. "1" for like and "0" for no like against the product_brand_id                                                              |
| user_time                | VARCHAR | The amount of time(in milliseconds) spent by a user on a particular brand                                                                                           |
| user_addcart             | VARCHAR | This shows whether the user has added the item shown on screen, to cart."1" for adding item to cart and "0" for not adding the item                                 |
| user_share               | VARCHAR | This data conveys  the user has clicked on the share button."1" for clicking share button against the item and "0" if not clicked.                                  |
| user_clickdesc           | VARCHAR | This data conveys whether the user clicked on description button of a particular brand. "1" for clicking description button against the item and "0" if not clicked.|
| product_brand_name       | VARCHAR | This shows the name of the item that user has viewed                                                                                                                |
| recom_brand_ids          | LIST    | This contains the product_brand_ids recommended for the user                                                                                                        |
| product_id               | VARCHAR | This is the id of the product                                                                                                                                       |
| product_name             | VARCHAR | This is the name of the product                                                                                                                                     |    



### Response example

    {
        "user_id": "1",
        "recom_brand_ids": ["1","6","89","56","12","56","23","89","888","63","12","03","20","52","235","236","598","213","98","78"]

    }
    """
    if request.method == 'POST':
        item_brand_ids = model(
            item.dict()["product_interaction_list"], item.dict()["user_id"])
        data = {
            "user_id": item.dict()["user_id"],
            "recom_brand_ids": item_brand_ids
        }
        return data



