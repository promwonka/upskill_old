from fastapi import FastAPI
from fastapi.security import OAuth2PasswordBearer

app = FastAPI()
oauth = OAuth2PasswordBearer(tokenUrl="token")


from app import main
from app.views import swagger_ui
