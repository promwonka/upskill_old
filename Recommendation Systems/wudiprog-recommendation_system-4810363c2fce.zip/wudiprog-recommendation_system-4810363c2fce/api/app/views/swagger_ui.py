from fastapi.openapi.utils import get_openapi
from app import app

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    openapi_schema = get_openapi(
        title="Wudi recomendation engine",
        version="1.0.0",
        description="The API can be called once a user interacts with 20 items on screen. Once the interaction data is sent, the API will recommend  20 item_brand_ids that are to be shown for the user",
        routes=app.routes,
        )
    openapi_schema["info"]["x-logo"] = {
        "url": "https://i.ibb.co/80KSGdS/1514973546regcompany.png"
        }
    app.openapi_schema = openapi_schema
    return app.openapi_schema


app.openapi = custom_openapi
