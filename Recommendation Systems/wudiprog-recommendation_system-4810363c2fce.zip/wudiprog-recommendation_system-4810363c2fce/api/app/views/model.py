# models and logics here

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from db.test import conn, db_test, get_name_from_itemid, get_best_brand, get_best_random, get_productid, get_user_intera_history, get_top_ranked, insert_data, insert_item, insert_purchase_hist,csv_creation

OUTPUT_NUMBER = 15
NUM_RECO = 1

listings = pd.read_csv(
    'list_2.csv', usecols=['product_id',
                           'product_name',
                           'product_desc',
                           'category_name',
                           'subcategory_name'])

listings['product_name'] = listings['product_name'].astype('str')
listings['product_desc'] = listings['product_desc'].astype('str')
name_corpus = ' '.join(listings['product_name'])
description_corpus = ' '.join(listings['product_desc'])

listings['content'] = listings[['product_name', 'product_desc']].astype(
    str).apply(lambda x: ' // '.join(x), axis=1)

listings['content'].fillna('Null', inplace=True)

tf = TfidfVectorizer(
    analyzer='word', ngram_range=(1, 2), min_df=0, stop_words='english')

tfidf_matrix = tf.fit_transform(listings['content'])
cosine_similarities = linear_kernel(tfidf_matrix, tfidf_matrix)

results = {}
for idx, row in listings.iterrows():
    similar_indices = cosine_similarities[idx].argsort()[:-100:-1]
    similar_items = [(
        cosine_similarities[idx][i],
        listings['product_id'][i]) for i in similar_indices]

    results[row['product_id']] = similar_items[1:]


def item(id):
    product = listings.loc[
        listings['product_id'] == id]['content'].tolist()[0].split(' // ')[0]

    return product


def get_recom(product_ids, num):
    items = []
    for product_id in product_ids:
        recs = results[int(product_id)][:int(100)]
        after_duplic = list(dict.fromkeys(recs))
        items.append([x[1] for x in after_duplic[:2]])
    items = [x for item in items for x in item]
    return items


def filter_recom(recoms, user_id):
    best_brands = []
    for recomend in recoms:
        best_brand = get_best_brand(recomend, user_id)
        best_brands.append(best_brand)
    avoid_duplic = list(dict.fromkeys(best_brands))
    print("actual")
    print(avoid_duplic)
    balance_num = OUTPUT_NUMBER - len(avoid_duplic)
    balance_item = get_best_random(balance_num)
    print("random")
    print(balance_item)
    top_list = avoid_duplic + balance_item
    last_list = get_user_intera_history(user_id)
    avoid_duplic_last = list(dict.fromkeys(last_list + top_list))
    print("histroy")
    print(avoid_duplic_last)
    if len(last_list) <= 5:
        top_list = top_list + get_best_random(5)
    top_list = top_list + avoid_duplic_last[:5]
    return top_list


def model(products, user_id):
    for data in products:
        insert_data(user_id,
                    data[0],  # brand_id
                    data[1],  # user_liked
                    data[2],  # user_addcart
                    data[3],  # user_clickdesc
                    data[4],  # user_share
                    data[5],  # user_time
                    data[6]   # recom_yn
                    )

    ranked_products = get_top_ranked(products)
    p_ids = []
    for product in ranked_products:
        p_id = get_productid(product)
        p_ids.append(p_id)
    after_duplic = list(dict.fromkeys(p_ids))
    items = get_recom(after_duplic[:10], NUM_RECO)
    recoms = filter_recom(items, user_id)
    item_brand_ids = []
    for ids in recoms:
        item_brand_ids.append(ids)
    # conn.close()
    return item_brand_ids


#new code

def insert_item_fn(itemfill_list):
    for data in itemfill_list:
        insert_item(data[0],  # brand_id
                    data[1],  # brand_name
                    data[2],  # product_id
                    data[3],  # product_name
                    data[4],  # product_desc
                    data[5],  # category_name
                    data[6],  # subcategory_name
                    data[7],  # user_rating
                    data[8],  # sales_rating
                    data[9],  # buy_again
                    data[10]  # push_product_brand 
                    )
    return



def insert_purch_hist_fn(user_purchase_list):
    for data in user_purchase_list:
        insert_purchase_hist(data[0],  # user_id
                             data[1],  # brand_id
                             data[2],  # user_bought
                             data[3],  # user_return
                             data[4],  # user_cancel
                             data[5],  # unit_price
                             data[6],  # unit_quantity
                             data[7],  # total_price
                             data[8],  # brand_discount
                             data[9],  # invoice_number
                             data[10], # invoice_date
                             data[11], # payment_mode
                             data[12], # total_invoice_amount
                             data[13], # total_invoice_discount
                             data[14], # coupon_code
                             data[15], # gift_or_not
                             )
    return

def create_csv_fn(csv_update):
   
    csv_creation(csv_update) # code
                                 
    return




# till here
