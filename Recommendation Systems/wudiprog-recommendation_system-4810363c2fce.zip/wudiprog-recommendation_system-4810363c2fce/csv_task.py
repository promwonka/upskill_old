import psycopg2
import datetime
import uuid
import pandas as pd
import schedule
import time


conn = psycopg2.connect(
    database="testdb",
    user="postgres",
    password="TestML123098",
    host="65.0.12.26")

cur = conn.cursor()


def fetch_data():
    
    cur.execute(
        "SELECT * FROM dbfilter_1"
        )
    rows = cur.fetchall()

    df = pd.DataFrame(rows, columns = ['table1_id','brand_id', 'brand_name', 'product_id', 'product_name', 'product_desc', 'category_name', 'subcategory_name', 'user_rating', 'sales_rating', 'buy_again']) 

    df.to_csv('list_2.csv', index = False)

    upd = 'sheet updated'
    return upd

#print(upd)


schedule.every(1).seconds.do(fetch_data)


while True:
  
    # Checks whether a scheduled task 
    # is pending to run or not
    schedule.run_pending()
    time.sleep(1)